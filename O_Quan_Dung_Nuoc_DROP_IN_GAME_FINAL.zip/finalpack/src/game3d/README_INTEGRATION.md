# O QUAN: DUNG NUOC — DROP-IN R3F ASSET INTEGRATION

Copy `public/assets/o-quan-dung-nuoc` into your project's `public/assets/` and copy the three files under `src/game3d/` into the matching source folder.

Requires:
- three
- @react-three/fiber
- @react-three/drei

Then:
```tsx
import { OQuanBoardAssets } from './game3d/OQuanBoardAssets';

<OQuanBoardAssets selectedId={selectedTile} onSelect={setSelectedTile} />
```

The layout is 10 dân ô + 2 quan ô. The package deliberately does NOT flatten the dioramas into long strips.

For dynamic gameplay, instantiate the character/resource GLBs from `assetRegistry.ts` as children of each tile's world group. Do not duplicate board geometry per token.

import * as THREE from 'three';
import { Clone, useGLTF } from '@react-three/drei';
import { assetUrl } from './assetRegistry';
import { BOARD_LAYOUT, BoardTile } from './boardLayout';

function Tile({ tile, selected = false, onSelect }: { tile: BoardTile; selected?: boolean; onSelect?: () => void }) {
  const { scene } = useGLTF(assetUrl(tile.asset));
  const root = scene.clone(true);
  root.traverse((o) => {
    const m = (o as THREE.Mesh).material as THREE.Material | THREE.Material[] | undefined;
    if (!m) return;
    const mats = Array.isArray(m) ? m : [m];
    mats.forEach((mat) => { mat.needsUpdate = true; });
  });
  return (
    <group position={tile.position} rotation={tile.rotation} onClick={(e) => { e.stopPropagation(); onSelect?.(); }}>
      <primitive object={root} />
      {selected && <mesh position={[0, .34, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[1.0, 1.08, 48]} />
        <meshBasicMaterial color="#F2B84B" transparent opacity={0.9} />
      </mesh>}
    </group>
  );
}

export function OQuanBoardAssets({ selectedId, onSelect }: { selectedId?: number | string; onSelect?: (id: number | string) => void }) {
  return <group>
    {BOARD_LAYOUT.map(tile => <Tile key={String(tile.id)} tile={tile} selected={tile.id === selectedId} onSelect={() => onSelect?.(tile.id)} />)}
  </group>;
}

export function preloadOQuanAssets() {
  [...new Set(BOARD_LAYOUT.map(x => x.asset))].forEach(file => useGLTF.preload(assetUrl(file)));
}

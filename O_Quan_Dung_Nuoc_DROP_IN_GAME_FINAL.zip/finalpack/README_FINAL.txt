Ô QUAN: DỰNG NƯỚC — FINAL STATIC GAME ASSET PACK

Includes 31 GLB assets plus Board_Full_Demo.glb and placement.json.
Designed for direct import into Three.js / React Three Fiber.

ART DIRECTION: stylized Vietnamese historical strategy-game miniature diorama, isometric, restrained Gen-Z polish, earthy PBR, terracotta roofs, stone, wood, bamboo, rice, red/gold banners.

INTEGRATION: Use the individual GLBs for dynamic occupancy/resource states. Board_Full_Demo.glb is a visual reference/integration baseline. placement.json contains the 10 dân ô + 2 quan ô layout.

LIMITATION: This pack is final for static geometry/material integration. Character locomotion, skeletal animation, VFX and gameplay state changes should be driven by the game engine.
